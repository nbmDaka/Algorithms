package Assignment2.LLExercies;

public class pb7 {
    public static void main(String[] args) {
        MyLinkedList<Integer> myLinkedList = new MyLinkedList<>();
        myLinkedList.add(4);
        myLinkedList.add(2);
        myLinkedList.add(2);
        myLinkedList.add(3);
        int iter = (myLinkedList.size() / 2) - 1;

        MyLinkedList<Integer> ts = new MyLinkedList<>();
        for (int i = 0; i < iter; i++){
            ts.add(myLinkedList.get(i) + myLinkedList.get(myLinkedList.size()-1-i));
        }
        int max = ts.get(0);
        for (int i = 1; i < ts.size(); i++){
            if (ts.get(i) > max){
                max = ts.get(i);
            }
        }

        System.out.println(max);
    }


}
