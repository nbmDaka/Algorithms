package Assignment2.LLExercies;

import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;

public class LinkedListTest {
    public static void main(String[] args) {
        LinkedList<Integer> list = new LinkedList<>();
        list.add(45);
        list.add(25);
        list.add(35);
        list.add(65);
        list.add(95);
        list.add(75);
        Collections.sort(list);
        for(int i = 0; i < list.size(); i++){
            System.out.print(list.get(i) + " ");
        }
        MyLinkedList<Integer> linkedList = new MyLinkedList<>();
        System.out.println(linkedList);
    }
}
