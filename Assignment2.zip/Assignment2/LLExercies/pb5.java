package Assignment2.LLExercies;

public class pb5 {
    public static void main(String[] args) {
        MyLinkedList<Integer> myLinkedList = new MyLinkedList<>();
        myLinkedList.add(1);
        myLinkedList.add(1);
        myLinkedList.add(2);
        myLinkedList.add(2);
        myLinkedList.add(3);
        for (int i = 0; i < myLinkedList.size(); i++){
            for(int j = 0; j < myLinkedList.size(); j++){
                if(i == j){
                    continue;
                }
                if(myLinkedList.get(i) == myLinkedList.get(j)){
                    myLinkedList.remove(j);
                }
            }
        }
        for(int i = 0; i < myLinkedList.size(); i++){
            System.out.println(myLinkedList.get(i));
        }
    }
}
