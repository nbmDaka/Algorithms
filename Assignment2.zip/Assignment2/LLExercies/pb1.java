package Assignment2.LLExercies;

public class pb1 {
    public static void main(String[] args) {
        MyLinkedList<Integer> nums = new MyLinkedList<>();
        nums.add(1);
        nums.add(2);
        nums.add(3);
        nums.add(4);
        nums.add(5);
        nums.add(6);
        nums.add(7);
        nums.add(8);
        nums.add(9);
        for (int i = (nums.size()/2) -1; i>=0; i--){
            nums.remove(i);
        }
        for(int i = 0; i < nums.size(); i++){
            System.out.print(nums.get(i) + " ");
        }
    }
}
