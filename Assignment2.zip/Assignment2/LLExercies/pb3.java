package Assignment2.LLExercies;

public class pb3 {
    public static void main(String[] args) {
    MyLinkedList<Integer> myLinkedList = new MyLinkedList<>();
    myLinkedList.add(1);
    myLinkedList.add(2);
    myLinkedList.add(3);
    myLinkedList.add(4);
    myLinkedList.add(5);
    myLinkedList.add(6);
    reverseList(myLinkedList,0, myLinkedList.size() - 1);
    for (int i = 0; i < myLinkedList.size(); i++){
        System.out.println(myLinkedList.get(i));
    }
    }

    public static void reverseList(MyLinkedList nums, int start, int end){
        if(start>=end){
            return;
        }
        Object temp = nums.get(start);
        nums.update(start, nums.get(end));
        nums.update(end, temp);
        reverseList(nums, start+1, end -1);
    }
}
