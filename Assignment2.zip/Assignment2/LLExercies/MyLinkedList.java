package Assignment2.LLExercies;

public class MyLinkedList<E> {
    private Node head;
    private int size;

    public MyLinkedList(){
        head = null;
        size = 0;
    }
    public void add(E value){
        Node<E> newNode = new Node<>(value);
        Node<E> currentNode = head;
        if(head == null){
            head = newNode;
            size++;
        }else {
            while(currentNode.next != null){
                currentNode = currentNode.next;
            }
            currentNode.next = newNode;
            size++;
        }
    }
    public void addFirst(E value){
        Node<E> newNode = new Node<>(value);
        newNode.next = head;
        head = newNode;
        size++;
    }

    public void remove(int index) {
        Node<E> currentNode = head;
        Node<E> previousNode = null;

        if (index == 0) {
            head = head.next;
            size--;
        } else {
            for (int i = 0; i < index; i++) {
                previousNode = currentNode;
                currentNode = currentNode.next;
            }
            previousNode.next = currentNode.next;
            size--;
        }
    }
    public E get(int index){
        Node<E> currentNode = head;
        if(index >= size){

        }
        {
            for(int i = 0; i < index; i++){
                currentNode = currentNode.next;
            }
            return currentNode.value;
        }
    }
    public int size(){
        return size;
    }
    public void add(int index, E value){
        Node<E> newNode = new Node<>(value);
        Node<E> currentNode = head;
        Node<E> previousNode = null;
        if(index == 0){
            newNode.next = head;
            head = newNode;
            size++;
            return;
        }
        if(index>=size){
            if(head == null){
                head = newNode;
                size++;
                return;
            }
            while(currentNode.next != null){
                currentNode = currentNode.next;
            }
            currentNode.next = newNode;
            size++;
            return;
        }
        for(int i = 0; i < index; i++){
            previousNode = currentNode;
            currentNode = currentNode.next;
        }
        previousNode.next = newNode;
        newNode.next = currentNode;
        size++;
    }
    public int update(int index, E value){
        Node<E> currentNode = head;
        Node<E> previousNode = null;
        Node<E> newNode = new Node<>(value);
        if(index == 0){
            newNode.next = head.next;
            head = newNode;
            return index;
        }

        for (int i = 0; i < index; i++){
            previousNode = currentNode;
            currentNode = currentNode.next;
        }
        newNode.next = currentNode.next;
        previousNode.next = newNode;

        return index;
    }
    public void removeV(E value){
        Node<E> currentNode = head;
        if(head.value == value){
            head = head.next;
            size--;
        } else{
            while(currentNode.next.value != value){
                currentNode = currentNode.next;
            }
            currentNode.next = currentNode.next.next;
            size--;
        }
    }
    public E findNthNodeFromEnd(int n) {
        Node<E> currentNode1 = head;
        Node<E> currentNode2 = head;
        for (int i = 0; i < n; i++) {
            currentNode1 = currentNode1.next;
        }
        while (currentNode1.next != null) {
            currentNode2 = currentNode2.next;
            currentNode1 = currentNode1.next;
        }
        return (E) currentNode2.value;
    }


    private static class Node <E> {
        private E value;
        private Node next;

        public Node(E value){
            this.value = value;
            this.next = null;
        }
    }

    }


