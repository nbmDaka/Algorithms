package Assignment2.LLExercies;

public class pb2 {
    public static void main(String[] args) {
        MyLinkedList<Integer> myLinkedList = new MyLinkedList<>();
        myLinkedList.add(1);
        myLinkedList.add(2);
        myLinkedList.add(3);
        myLinkedList.add(4);
        myLinkedList.add(5);
        myLinkedList.add(6);
        myLinkedList.add(7);
        myLinkedList.add(8);
        myLinkedList.add(9);
        System.out.println(myLinkedList);

        int j = myLinkedList.size() - 1;
        for (int i = 0; i < myLinkedList.size() / 2; i++){
            Object temp = myLinkedList.get(i);
            myLinkedList.update(i, (Integer) myLinkedList.get(j-i));
            myLinkedList.update(j-i,(Integer) temp);
        }
        for (int i = 0; i < myLinkedList.size(); i++){
            System.out.println(myLinkedList.get(i));
        }
    }
    }

