package Assignment2.LLExercies;

public class pb6 {
    public static void main(String[] args) {
        MyLinkedList<Integer> myLinkedList = new MyLinkedList<>();
        myLinkedList.add(4);
    }
}
