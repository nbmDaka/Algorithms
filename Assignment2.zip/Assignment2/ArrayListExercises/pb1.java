package Assignment2.ArrayListExercises;

import java.util.ArrayList;

public class pb1 {
    public static void main(String[] args) {
        MyArrayList<String> myArrayList = new MyArrayList<>();
        myArrayList.add("SE 2223");
        myArrayList.add("BDA 2213");
        myArrayList.add("CS 2236");
        myArrayList.add("Nurdaulet");
        myArrayList.add("Beketov");
        for(int i = 0; i<myArrayList.size();i++){
            System.out.println(myArrayList.get(i));
        }
        ArrayList<Integer> integers = new ArrayList<>();
    }
}
