package Assignment2.ArrayListExercises;

public class book {
    String title;
    String details;

    public book(String title, String details) {
        this.title = title;
        this.details = details;
    }

    public String getTitle() {
        return title;
    }

    public String getDetails() {
        return details;
    }
}
