package Assignment2.ArrayListExercises;

import java.util.Arrays;
import java.util.Objects;

public class MyArrayList<E>  {
        private Object[] array;
        private int size;

        public MyArrayList() {
        this.array = new Object[]{};
        }
        public MyArrayList(int capacity){
                if(capacity>0){
                        this.array = new Object[capacity];
                } else if (capacity==0) {
                        this.array = new Object[]{};
                }
        }
        public int size(){
                return size;
        }

        public E get(int index){
                Objects.checkIndex(index,size);
                return (E) array[index];
        }
        public void set(E e, int index){
                for(int i = 0; i < array.length; i++){
                        if(i == index){
                                array[i] = e;
                        }
                }
        }
        /* private E array(int index) {
                return (E) array[index];
        }*/

        public Object[] getArr(){
                Object[] arr2 = new Object[size];
                for (int i = 0; i < size; i++){
                        arr2[i] = array[i];
                }
                return arr2;
        }
//______________________________________________________________________________________________________________________
        private Object[] grow(int capacity){
                capacity++;
                Object array2[] =  new Object[capacity];
                for (int i = 0; i < size; i++) {
                        array2[i] = array[i];
                }
                array = array2;
                return array;
        }


        private void add(E e,Object[] array, int s){
                if(s == array.length){
                        array = grow(size+1);
                }
                array[s] = e;
                size = s + 1;
        }
        public boolean add(E e){
                add(e,array,size);
                return true;
        }
//______________________________________________________________________________________________________________________

        public void remove(int index) {
                if (index < 0 || index >= size) {
                        throw new IndexOutOfBoundsException("Index " + index + " is out of bounds!");
                }
                Object[] newArray = new Object[size - 1];
                int newArrayIndex = 0;
                for (int i = 0; i < size; i++) {
                        if (i != index) {
                                newArray[newArrayIndex] = array[i];
                                newArrayIndex++;
                        }
                }
                array = newArray;
                size--;
        }
        public String toString(){
                return Arrays.toString(array);
        }
}
