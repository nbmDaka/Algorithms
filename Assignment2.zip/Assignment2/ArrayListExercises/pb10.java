package Assignment2.ArrayListExercises;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class pb10 {
    public static void main(String[] args) throws FileNotFoundException {
        File file = new File("C:/Users/Nurdaulet/IdeaProjects/ADS Assainment1/src/Assignment2/Files/dates.txt");
        Scanner scannerFile = new Scanner(file);
        MyArrayList<String> dates= new MyArrayList<>();
        while(scannerFile.hasNextLine()){
            dates.add(scannerFile.nextLine());
        }
        for (int i = 0; i < dates.size(); i++){
            for (int j = 0; j < dates.size()-i-1; j++){
                String[] date1 = dates.get(j).split("[.]+");
                int day1 = Integer.parseInt(date1[0]);
                String[] date2 = dates.get(j+1).split("[.]+");
                int day2 = Integer.parseInt(date2[0]);
                if(day1 > day2){
                    String tempDate = dates.get(j);
                    dates.set(dates.get(j+1), j);
                    dates.set(tempDate, j+1);
                }
            }

        }
        for (int i = 0; i < dates.size(); i++){
            for (int j = 0; j < dates.size()-i-1; j++){
                String[] date1 = dates.get(j).split("[.]+");
                int month1 = Integer.parseInt(date1[1]);
                String[] date2 = dates.get(j+1).split("[.]+");
                int month2 = Integer.parseInt(date2[1]);
                if(month1 > month2){
                    String tempDate = dates.get(j);
                    dates.set(dates.get(j+1), j);
                    dates.set(tempDate, j+1);
                }
            }

        }
        for (int i = 0; i < dates.size(); i++){
            for (int j = 0; j < dates.size()-i-1; j++){
                String[] date1 = dates.get(j).split("[.]+");
                int year1 = Integer.parseInt(date1[2]);
                String[] date2 = dates.get(j+1).split("[.]+");
                int year2 = Integer.parseInt(date2[2]);
                if(year1 > year2){
                    String tempDate = dates.get(j);
                    dates.set(dates.get(j+1), j);
                    dates.set(tempDate, j+1);
                }
            }
        }

        for(Object i : dates.getArr()){
            System.out.println(i);
        }
    }
}
