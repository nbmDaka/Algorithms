package Assignment2.ArrayListExercises;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class pb10 {
    public static void main(String[] args) throws FileNotFoundException {
        MyArrayList<String> myArrayList = new MyArrayList<>();
        File file = new File("C:/Users/Nurdaulet/IdeaProjects/ADS Assainment1/src/Assignment2/Files/dates.txt");

        Scanner scanner = new Scanner(file);
        while(scanner.hasNext()){
            String dates = scanner.nextLine();
            myArrayList.add(dates);
        }
        for(int i = 0; i < myArrayList.size() - 1; i++){
            for(int j = 0; j < myArrayList.size() - i - 1; j++){
                String[] day1 = myArrayList.get(j).split("[.]+");
                int day11 = Integer.parseInt(day1[0]);
                String[] day2 = myArrayList.get(j+1).split("[.]+");
                int day12 = Integer.parseInt(day2[0]);
                if(day11> day12){
                    String temp = myArrayList.get(j);
                    myArrayList.set(myArrayList.get(j + 1),j);
                    myArrayList.set(temp,j + 1);
                }
            }
        }

        for(int i = 0; i < myArrayList.size() - 1; i++){
            for(int j = 0; j < myArrayList.size() - i - 1; j++){
                String[] month1 = myArrayList.get(j).split("[.]+");
                int month11 = Integer.parseInt(month1[1]);
                String[] month2 = myArrayList.get(j+1).split("[.]+");
                int month12 = Integer.parseInt(month2[1]);
                if(month11> month12){
                    String temp = myArrayList.get(j);
                    myArrayList.set(myArrayList.get(j + 1),j);
                    myArrayList.set(temp,j + 1);
                }
            }
        }
        for(int i = 0; i < myArrayList.size() - 1; i++){
            for(int j = 0; j < myArrayList.size() - i - 1; j++){
                String[] year1 = myArrayList.get(j).split("[.]+");
                int year11 = Integer.parseInt(year1[2]);
                String[] year2 = myArrayList.get(j+1).split("[.]+");
                int year12 = Integer.parseInt(year2[2]);
                if(year11> year12){
                    String temp = myArrayList.get(j);
                    myArrayList.set(myArrayList.get(j + 1),j);
                    myArrayList.set(temp,j + 1);
                }
            }
        }


        for(int i = 0; i < myArrayList.size(); i++){
            System.out.println(myArrayList.get(i));
        }


    }
}
