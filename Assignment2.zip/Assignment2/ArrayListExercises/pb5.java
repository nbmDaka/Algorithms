package Assignment2.ArrayListExercises;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class pb5 {
    public static void main(String[] args) {
        MyArrayList<Integer> numbers = new MyArrayList<>();


        try {
            File file = new File("C:/Users/Nurdaulet/IdeaProjects/ADS Assainment1/src/Assignment2/Files/data.txt");
            Scanner scannerFile = new Scanner(file);

            while (scannerFile.hasNextInt()) {
                int number = scannerFile.nextInt();
                numbers.add(number);
            }

            scannerFile.close();
        } catch (FileNotFoundException e) {
            System.out.println("File not found.");
        }

        int sum = 0;
        for (int  i = 0; i< numbers.size();i++){
            sum+= numbers.get(i);
        }

        double averege = sum / numbers.size();

        System.out.println("Sum: " + sum + "\nAverage: " + averege);
    }
}
