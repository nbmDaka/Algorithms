package Assignment2.ArrayListExercises;
import java.io.*;
import java.util.Scanner;

public class pb5 {
    public static void main(String[] args) throws IOException {
        MyArrayList<Integer> myArrayList = new MyArrayList<>();
        File file = new File("C:/Users/Nurdaulet/IdeaProjects/ADS Assainment1/src/Assignment2/Files/data.txt");
        try {
            Scanner scanner = new Scanner(file);
            while(scanner.hasNext()) {
                if(scanner.hasNextInt()){
                    int number = scanner.nextInt();
                    myArrayList.add(number);
                } else {
                    System.out.println("Skipping non integer value "+ scanner.next());
                }
            }
            scanner.close();
            } catch (FileNotFoundException e){
            System.out.println("File not found " + e.getMessage());
        }
        for(int i = 0; i < myArrayList.size(); i++){
            System.out.print(myArrayList.get(i) + " ");
        }
    }

}
