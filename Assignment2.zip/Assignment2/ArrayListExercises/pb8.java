package Assignment2.ArrayListExercises;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class pb8 {
    public static void main(String[] args) throws FileNotFoundException {
        MyArrayList<book> books = new MyArrayList<>();

        File file = new File("C:/Users/Nurdaulet/IdeaProjects/ADS Assainment1/src/Assignment2/Files/book.txt");
        Scanner scannerFile = new Scanner(file);

        while(scannerFile.hasNextLine()){
            String[] arrS = scannerFile.nextLine().split(": ");
            books.add(new book(arrS[0], arrS[1]));
        }

        Scanner in = new Scanner(System.in);

        String title = in.nextLine();

        if(bookExists(title, books)){
            System.out.println(bookDetails(title, books));
        }else{
            System.out.println("NOT FOUND");
        }
    }

    public static boolean bookExists(String title, MyArrayList list){
        boolean exists = false;
        for (int i = 0; i < list.size(); i++){
            book book = (Assignment2.ArrayListExercises.book) list.get(i);
            if (book.getTitle().equals(title)){
                exists = true;
            }
        }
        return exists;
    }

    public static String bookDetails(String title, MyArrayList list){
        String details = null;
        for (int i = 0; i < list.size(); i++){
            book book = (Assignment2.ArrayListExercises.book) list.get(i);
            if (book.getTitle().equals(title)){
                details = book.getDetails();
            }
        }
        return details;
    }
}
