package Assignment2.ArrayListExercises;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class pb8 {
    static MyArrayList<book> myArrayList = new MyArrayList<>();
    public static void main(String[] args) {
     File file = new File("C:/Users/Nurdaulet/IdeaProjects/ADS Assainment1/src/Assignment2/Files/book.txt");


     try{
         Scanner scanner = new Scanner(file);
         while(scanner.hasNext()){
             String line = scanner.nextLine();
             String[] parts = line.split(": ");
             if (parts.length == 2) {
                 book book = new book(parts[0], parts[1]);
                 myArrayList.add(book);
             } else {
                 System.out.println("Invalid format: " + line);
             }

         }
     } catch (FileNotFoundException e) {
         throw new RuntimeException(e);
     }
        Scanner scanner = new Scanner(System.in);
        search(scanner.nextLine());
    }
    private static void search(String title){
        boolean found = false;
        for(int i = 0; i < myArrayList.size(); i++){
            if(myArrayList.get(i).getTitle().equals(title)){
                System.out.println(myArrayList.get(i).getDetails());
                found = true;
            }
        }
        if (!found) {
            System.out.println("Book not found.");
        }
    }
}

