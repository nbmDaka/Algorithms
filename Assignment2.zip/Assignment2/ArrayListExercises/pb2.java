package Assignment2.ArrayListExercises;

import java.util.ArrayList;
import java.util.Collections;

public class pb2 {
    public static void main(String[] args) {
        ArrayList<Integer> arrayList = new ArrayList<>();
        arrayList.add((int) (Math.random() * 10) + 1);
        arrayList.add((int) (Math.random() * 10) + 1);
        arrayList.add((int) (Math.random() * 10) + 1);
        arrayList.add((int) (Math.random() * 10) + 1);
        arrayList.add((int) (Math.random() * 10) + 1);
        arrayList.add((int) (Math.random() * 10) + 1);
        Collections.sort(arrayList);
        System.out.println(arrayList);


    }
}
