package Assignment2.ArrayListExercises;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;

public class pb6 {
    public static void main(String[] args) throws FileNotFoundException {
        File file = new File("C:/Users/Nurdaulet/IdeaProjects/ADS Assainment1/src/Assignment2/Files/strings.txt");
        Scanner scannerFile = new Scanner(file);
        MyArrayList<String> strings = new MyArrayList<>();
        while (scannerFile.hasNextLine()){
            String string = scannerFile.nextLine();
            strings.add(string);
        }

        for (int i = 0; i < strings.size(); i++){
            for (int j = 0; j < strings.size(); j++){
                if (j == i){
                    continue;
                }
                String a = (String) (strings.get(i));
                String b = (String) (strings.get(j));
                if (a.equals(b)){
                    strings.remove(j);
                }
            }
        }

        for(int i = 0; i < strings.size(); i++){
            System.out.println(strings.get(i));
        }
    }
}
