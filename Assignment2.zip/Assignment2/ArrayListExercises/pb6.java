package Assignment2.ArrayListExercises;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class pb6 {
    public static void main(String[] args) {
        MyArrayList<String> myArrayList = new MyArrayList<>();
        File file = new File("C:/Users/Nurdaulet/IdeaProjects/ADS Assainment1/src/Assignment2/Files/strings.txt");
        try{
            Scanner scanner = new Scanner(file);
            while(scanner.hasNext()){
                if(scanner.hasNextLine()){
                    String strings = scanner.nextLine();
                    myArrayList.add(strings);
                }
            }
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
        for (int i = 0; i < myArrayList.size(); i++){
            for(int j = 0; j < myArrayList.size(); j++){
                if(i == j){
                    continue;
                }
                String a = myArrayList.get(i);
                String b = myArrayList.get(j);
                if(a.equals(b)){
                    myArrayList.remove(j);
                }
            }
        }
        for(int i = 0; i < myArrayList.size(); i++){
            System.out.print(myArrayList.get(i)+ " ");
        }
    }
}
