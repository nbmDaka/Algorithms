package Assignment2.ArrayListExercises;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class pb7 {
    public static void main(String[] args) throws FileNotFoundException {
        File file = new File("C:/Users/Nurdaulet/IdeaProjects/ADS Assainment1/src/Assignment2/Files/student.txt");
        Scanner ScannerFile = new Scanner(file);
        MyArrayList<Student> students = new MyArrayList<>();

        while (ScannerFile.hasNextLine()){
            String name = ScannerFile.next();
            int grade = Integer.parseInt(ScannerFile.next());
            Student student = new Student(name, grade);
            students.add(student);
        }
        for (int i = 0; i < students.size(); i++){
            for (int j = 0; j < students.size()-i-1; j++){
                if (students.get(j+1).getGrade() > students.get(j).getGrade()){
                    Student tempStudent = students.get(j);
                    students.set(students.get(j+1), j);
                    students.set(tempStudent, j+1);
                }
            }
        }
        for (int i = 0; i < students.size(); i++){
            System.out.print(students.get(i).getName() + " " + students.get(i).getGrade() + "\n");
        }

    }
}


