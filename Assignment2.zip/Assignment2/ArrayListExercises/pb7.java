package Assignment2.ArrayListExercises;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class pb7 {
    public static void main(String[] args) {
        File file = new File("C:/Users/Nurdaulet/IdeaProjects/ADS Assainment1/src/Assignment2/Files/student.txt");
        MyArrayList<Student> myArrayList = new MyArrayList<>();
        try{
            Scanner scanner = new Scanner(file);

            while(scanner.hasNext()){
                String name = scanner.next();
                int grade = Integer.parseInt(scanner.next());
                Student student = new Student(name,grade);
                myArrayList.add(student);
            }
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
        for (int i = 0; i < myArrayList.size(); i++){
            for (int j = 0; j < myArrayList.size()-i-1; j++){
                if (myArrayList.get(j+1).getGrade() > myArrayList.get(j).getGrade()){
                    Student temp = myArrayList.get(j);
                    myArrayList.set(myArrayList.get(j+1), j);
                    myArrayList.set(temp, j+1);
                }
            }
        }

        for(int i = 0; i < myArrayList.size(); i++){
            System.out.println(myArrayList.get(i).getName() + " " + myArrayList.get(i).getGrade());
        }
    }
}
