package Assignment2.ArrayListExercises;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class pb4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        MyArrayList<Integer> arrayList = new MyArrayList<>();
        int n =(int)(Math.random()*11);
        System.out.println(n);
        int[] someNumbers = new int[n];
        for(int i = 0; i< n;i++){
            someNumbers[i] = scanner.nextInt();
        }
        for(int i = 0; i < n; i++){
            arrayList.add(someNumbers[i]);
        }
        int min = Integer.MAX_VALUE;
        int max = Integer.MIN_VALUE;
        for(int i = 0; i < arrayList.size(); i++){
            if(arrayList.get(i)<min) min = arrayList.get(i);
        }
        for(int i = 0; i < arrayList.size(); i++){
            if(arrayList.get(i)>max) max = arrayList.get(i);
        }
        System.out.println(min);
        System.out.println(max);
    }

}
