package Assignment2.ArrayListExercises;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class pb9 {
    public static void main(String[] args) throws FileNotFoundException {
        File file = new File("C:/Users/Nurdaulet/IdeaProjects/ADS Assainment1/src/Assignment2/Files/employees.txt");
        Scanner scannerFile = new Scanner(file);
        MyArrayList<Employee> employees = new MyArrayList<>();

        while(scannerFile.hasNextLine()){
            String[] emp = scannerFile.nextLine().split(": ");
            double salary = Double.parseDouble(emp[1]);
            employees.add(new Employee(emp[0],
                    salary));
        }

        double TotalSalary = 0;

        for (Object i : employees.getArr()){
            Employee temp = (Employee) i;
            TotalSalary += temp.getSalary();
        }
        System.out.println(TotalSalary);


    }
}

class Employee {
    String name;
    double salary;
    public Employee(String name, double salary) {
        this.name = name;
        this.salary = salary;
    }
    public String getName() {
        return name;
    }
    public double getSalary() {
        return salary;
    }
    }

