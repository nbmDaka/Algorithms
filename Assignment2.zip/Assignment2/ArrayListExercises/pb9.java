package Assignment2.ArrayListExercises;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class pb9 {
    public static void main(String[] args) {
    MyArrayList<Employee> myArrayList = new MyArrayList<>();
    File file = new File("C:/Users/Nurdaulet/IdeaProjects/ADS Assainment1/src/Assignment2/Files/employees.txt");
    try{
        Scanner scanner = new Scanner(file);
        while(scanner.hasNext()){
            String line = scanner.nextLine();
            String[] parts = line.split(": ");
            if (parts.length == 2) {
                Employee employee = new Employee(parts[0],Double.parseDouble(parts[1]));
                myArrayList.add(employee);
            } else {
                System.out.println("Invalid format: " + line);
            }
        }
    } catch (FileNotFoundException e) {
        throw new RuntimeException(e);
    }
    double sum = 0;
        for(int i = 0; i < myArrayList.size(); i++){
            sum+=myArrayList.get(i).getSalary();
        }
        System.out.println("Sum is: "+ sum);
    }
}
