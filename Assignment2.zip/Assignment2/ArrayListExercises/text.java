package Assignment2.ArrayListExercises;

public class text {
    public static void main(String[] args) {
        MyArrayList<Integer> myArrayList = new MyArrayList<>();
        myArrayList.add(78);
        myArrayList.add(85);
        myArrayList.add(98);
        myArrayList.add(62);
        myArrayList.add(32);
        myArrayList.add(91);
        myArrayList.add(25);
        myArrayList.add(14);
        for(int i = 0; i < myArrayList.size(); i++){
            System.out.println(myArrayList.get(i));
        }
        System.out.println("___________________________");
        myArrayList.remove(5);

        for(int i = 0; i < myArrayList.size(); i++){
            System.out.println(myArrayList.get(i));
        }
    }
}
