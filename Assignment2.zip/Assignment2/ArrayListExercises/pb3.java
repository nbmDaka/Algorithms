package Assignment2.ArrayListExercises;

import java.awt.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class pb3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<String> arrayList = new ArrayList<>();
        int n = (int) (Math.random() * 10) + 1;
        System.out.println(n);
        String[] someWords = new String[n];
        for(int i = 0; i<n; i++){
            someWords[i] = scanner.nextLine();
        }
        for(int i = 0; i < n; i++){
            arrayList.add(someWords[i]);
        }
        Collections.sort(arrayList);
        System.out.println(arrayList);
    }
}
